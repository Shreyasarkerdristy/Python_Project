from pathlib import Path
import json

# Read data as a string and convert to a Python object.
path=Path(r"G:\4-2\python_programe\project\GeoJSON data\eq_data_1_day_m1.geojson")
contents = path.read_text(encoding="utf-8")
all_eq_data = json.loads(contents)


"""# Create a more readable version of the data file.
out_path = Path(r"G:\4-2\python_programe\project\GeoJSON data\readable_eq_data.geojson")
readable_contents = json.dumps(all_eq_data, indent=4)
out_path.write_text(readable_contents, encoding="utf-8")"""

#examine all the earthquakes in the dataset
all_eq_dicts=all_eq_data['features']
print(len(all_eq_dicts))

mags,lons,lats=[],[],[]
for i in all_eq_dicts:
    mag=i['properties']['mag']
    lon=i['geometry']['coordinates'][0]
    lat=i['geometry']['coordinates'][1]
    mags.append(mag)
    lons.append(lon)
    lats.append(lat)
print(mags[:10])
print(lons[:5])
print(lats[:5])
