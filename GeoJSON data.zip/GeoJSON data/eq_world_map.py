from pathlib import Path
import json
import plotly.express as px

# Read data as a string and convert to a Python object.
path=Path(r"G:\4-2\python_programe\project\GeoJSON data\eq_data_30_day_m1.geojson")
contents = path.read_text(encoding="utf-8")
all_eq_data = json.loads(contents)

#examine all the earthquakes in the dataset
all_eq_dicts=all_eq_data['features']

mags,lons,lats,eq_titles=[],[],[],[]
for i in all_eq_dicts:
    mag=i['properties']['mag']
    lon=i['geometry']['coordinates'][0]
    lat=i['geometry']['coordinates'][1]
    eq_title=i['properties']['title']
    mags.append(mag)
    lons.append(lon)
    lats.append(lat)
    eq_titles.append(eq_title)
title = 'Global Earthquakes'
fig = px.scatter_geo(lat=lats, lon=lons, size=mags,title=title,
                     color=mags,
                     color_continuous_scale='Viridis',
                     labels={'color':'Magnitude'},
                     projection='natural earth',
                     hover_name=eq_titles,)
fig.show()